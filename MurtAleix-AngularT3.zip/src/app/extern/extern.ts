import { Component } from '@angular/core';

@Component({
  selector: 'app-extern',
  imports: [],
  templateUrl: './extern.html',
  styleUrl: './extern.css',
})
export class ExternComponent {

}
